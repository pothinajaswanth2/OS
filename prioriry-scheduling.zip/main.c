/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int bt[20], pro[20], tat[20],wt[20], pr[20],i,j,n,pos,temp,avg_wt,avg_tat,total=0;
    printf("\nEnter no of processes- ");
    scanf("%d", &n);
    
    printf("\nEnter busrt time and priority- ");
    for(i=0; i<n; i++)
    {
        printf("\n p[%d] ", i+1);
        printf("\n Burst time- ");
        scanf("%d", &bt[i]);
        printf("\n Priority- ");
        scanf("%d", &pr[i]);
        pro[i]=i+1;
    }
    
    for(i=0; i<n; i++)
    {
        pos=i;
        for(j=i; j<n; j++)
        {
            if(pr[j]<pr[pos])
            {
                pos=j;
            }
        }
        
        temp=pr[i];
        pr[i]=pr[pos];
        pr[pos]=temp;
        
        temp=bt[i];
        bt[i]=bt[pos];
        bt[pos]=bt[i];
        
        temp=pro[i];
        pro[i]=pro[pos];
        pro[pos]=temp;
    }
    
    wt[0]=0;
    
    for(i=0; i<n; i++)
    {
        wt[i]=0;
        for(j=0; j<i; j++)
        {
            wt[i]= wt[i]+bt[j];
        }
        total=total+wt[i];
    }
    
    avg_wt=total/n;
    total=0;
    
    printf("\nProcess\t Busrt time\t Waiting time\t Turn Around Time");
    for(i=0;i<n;i++)
    {
        tat[i]=bt[i]-wt[i];
        total=total+tat[i];
        printf("\n p[%d]\t  %d\t          %d\t           %d\t", pro[i],bt[i],wt[i],tat[i]);
    }
    
    avg_tat=total/n;
    printf("\n Average waiting time- %d",avg_wt);
    printf("\n Average Turnaround time- %d",avg_tat);
    
return 0;
}
